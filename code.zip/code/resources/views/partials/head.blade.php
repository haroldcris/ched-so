<!-- Icons -->
<link href="/vendor/fontawesome/css/all.min.css" rel="stylesheet">
<link href="/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">

<!-- Main styles for this application -->
<link href="/css/style.min.css" rel="stylesheet">

