<footer class="main-footer pt-3 pb-2">
	
	<div class="footer-left">
	  <span>CHED © 2020</span>
	</div>

	<div class="footer-right">
	    <span class="ml-auto">Powered by CHED</span>
	</div>

</footer>
