this is to create course code


<form method='POST' action="{{ route('coursecode.store') }}">
	@csrf
	
<button type='submit'>OKAY</button>

</form>