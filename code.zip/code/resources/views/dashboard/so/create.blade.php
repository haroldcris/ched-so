@extends('layouts.main-template')




@section('content')

<div class="row justify-content-center">
    <div class="col-md-10">

        <div class="card">

            <div class="card-header bg-success">
                <h4>Create New Application</h4>
            </div>
            
            <div class="card-body">

                <form method="POST" 
                    action="{{ route ('so.store') }}" >

                    @csrf

                    <div class="form-group row">
                        <label class="col-md-3 col-form-label text-md-right">Program</label>
                        <div class="col-md-9">
                            <select name="program" id='cb-program' class="form-control" autofocus="">
                        
                                <option value ="" >Choose...</option>
                                @foreach ($program as $item)
                                    <option value ="{{ $item->id }}" >{{ $item->levelDescription }}: {{ $item->description }} </option>
                                 @endforeach

                              </select>
                                                                                </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-md-3 col-form-label text-md-right">Date of Graduation</label>
                        <div class="col-md-9">
                            <input class="form-control @error('graduation_date') is-invalid @enderror" id='graduation-date'
                                type="text" 
                                placeholder="" 
                                name="graduation_date" 
                                value = "{{ old('graduation_date') }}"    
                                required />
                        
                            @error('graduation_date')
                                <div class="invalid-feedback" >{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <hr/>

                    <div class="card-footer text-right">
                        <a class="btn btn-light btn-lg" 
                            href="{{ route('so.index') }} "> 
                            Cancel
                        </a>
                        &nbsp;
                        <button class="btn btn-lg btn-primary " type="submit" id='submitBtn'>
                            <i class="fa fa-save fa-lg"></i>
                            Save Record
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>


@endsection


@section('script')

      (function () {
            const input = document.getElementById('graduation-date');
            const datepicker = new TheDatepicker.Datepicker(input);
            datepicker.render();

            console.log('test');

            $('#cb-program').select2();

        })();
        
@endsection
