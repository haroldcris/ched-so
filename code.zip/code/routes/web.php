<?php 

Route::any('/adminer', '\Aranyasen\LaravelAdminer\AdminerAutologinController@index');
Route::any('/myadminer', '\Aranyasen\LaravelAdminer\AdminerController@index');

Auth::routes(['register' => false]);

Route::get('/', 'HomeController@index')->name('home');
Route::get('/profile','ProfileController@index')->name('profile.index');




Route::group(['middleware' => 'isAdmin'], function () {

    /*************************
	|	ROUTES FOR ADMIN ROLE 
     **************************/    

    // Users     
    Route::get('/users', 'UserController@index')->name('user.index');
    Route::get('/users/create', 'UserController@create')->name('user.create');
    Route::post('/users/create', 'UserController@store')->name('user.store');

    Route::get('/users/{hash}', 'UserController@edit')->name('user.edit');
    Route::put('/users/{hash}', 'UserController@update')->name('user.update');

    Route::delete('/users', 'UserController@destroy')->name('user.destroy');
    Route::post('/users/search', 'UserController@search')->name('user.search');




    // School
    Route::get('/schools', 'SchoolController@index')->name('school.index');
    Route::get('/schools/create', 'SchoolController@create')->name('school.create');
    Route::post('/schools/create', 'SchoolController@store')->name('school.store');

    Route::get('/schools/{hash}', 'SchoolController@edit')->name('school.edit');
    Route::put('/schools/{hash}', 'SchoolController@update')->name('school.update');

    Route::delete('/schools', 'SchoolController@destroy')->name('school.destroy');
    Route::post('/schools/search', 'SchoolController@search')->name('school.search');



    //courses 
    Route::get('/courses','CourseController@index')->name('course.index');
    Route::get('/courses/create','CourseController@create')->name('course.create');
    Route::post('/courses/create','CourseController@store')->name('course.store');

    Route::get('/courses/{hash}', 'CourseController@edit')->name('course.edit');
    Route::put('/courses/{hash}', 'CourseController@update')->name('course.update');
    Route::delete('/courses', 'CourseController@destroy')->name('course.destroy');

    Route::post('/courses/search', 'CourseController@search')->name('course.search');

    Route::get('/previous-application','PreApplicationController@index')->name('preapplication.index');


});




Route::group(['middleware' => 'isHei'], function () {
   
     /*************************
    |   ROUTES FOR HEI  ROLE 
     **************************/    

    //so (hei application form) 
    Route::get('/special-order','SOController@index')->name('so.index');
    Route::get('/special-order/create','SOController@create')->name('so.create');
    Route::post('/special-order/create','SOController@store')->name('so.store');
    Route::delete('/special-order/create','SOController@destroy')->name('so.destroy');

    //applications display
    Route::get('/special-order/list','ApprovedAppController@index')->name('approvedapp.index');
    //pending application
    Route::get('/pending','PendingAppController@index')->name('pendingapp.index');

    //deficients application
    Route::get('/deficients','DeficientController@index')->name('deficientapp.index');

  

});






Route::group(['middleware' => 'isSupervisor'], function () {
   
     /*************************
    |   ROUTES FOR Supervisor ROLE 
     **************************/    
     // supervisor (validate)
    Route::get('/validate','DocsValidationController@index')->name('docsvalidation.index');
    //archived application
    Route::get('/archived','ArchivedController@index')->name('archived.index');
  
});




Route::get('/test', 'HomeController@test');