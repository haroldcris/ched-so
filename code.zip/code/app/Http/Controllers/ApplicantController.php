<?php

namespace App\Http\Controllers;


use App\Models\Courses;
use App\Models\Applicant;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\HashGenerator;

class ApplicantController extends Controller
{
	public function 

	public function index()
	{
		$applicant = Applicant::all();
		return view('dashboard.applicant.index',['applicant' => $applicant]);
	}

	public function create()
	{
		// $applicantname = Applicant::select(DB::raw("CONCAT('lastname','firstname','middlename') AS Name"))->get();
		
		$program = Courses::select('schoolcode','program')->get();   

		return view('dashboard.applicant.create',['program' => $program]);
	}

	public function store(Request $request)
	{
		$data = $request->validate([
			'schoolcode'  => ['required', 'string', 'max:50'],
			'program'     => ['required'],
			'lastname' =>['required', 'string', 'max:100'],
			'firstname' =>['required', 'string', 'max:100'],
			'middlename' =>['required', 'string', 'max:100'],
			'batch' =>['required', 'string', 'max:50']
		]);



		Applicant::create([
			'schoolcode'      => $data['schoolcode'],
			'program'         => $data['program'],
			'lastname'         => $data['lastname'],
			'firstname'         => $data['firstname'],
			'middlename'         => $data['middlename'],
			'batch'         	=> $data['batch']
			//applicant name pagsasamahin lastname middlename firstname
		]);

		$request->session()->flash('message', 'Record has been created');

		return redirect()->route('applicant.index');
	}


	public function edit($hash)
	{
	 	
	 	$value = HashGenerator::Decode($hash);
	 	// dd($value, $hash);

		$data = Applicant::where('id',$value)->firstOrFail();

		$applicantname = Applicant::select('lastname','firstname','middlename')->get();                
		$program =  Applicant::select('program')->get();
		$batch =  Applicant::select('batch')->get();



		return view('dashboard.applicant.edit', [ 'program' => $program,
			 'batch' => $batch,
			'applicantname' => $applicantname, 
			'data' => $data]);        
	}


	public function update(Request $request, $hash)
	{

		$value = HashGenerator::Decode($hash);

		$item = Applicant::where('id',$value)->firstOrFail();
		

		$validated = $request->validate([
		'schoolcode'   => 'required|unique:applicant,schoolcode,'.$item->schoolcode.',schoolcode',
			'program'   => 'required',
			'lastname'   => 'required',
			'firstname' => 'required',
			'middlename' => 'required',
			'batch' => 'required'
		]);
		// dd($validated);
		$item->update($request->all());

		$request->session()->flash('message', 'Record has been successfully Updated');
		return redirect()->route('applicant.index');
	}

	public function destroy(Request $request)
	{
		$item = Applicant::where('id',$request->input('id'))
		->firstOrFail();

		// if($item->username == 'admin')
		// 	abort(401, 'Not Allowed to Delete Admin' );

		$item->delete();

		$request->session()->flash('message', 'Item Deleted Successfully');
		return back();
	}

}