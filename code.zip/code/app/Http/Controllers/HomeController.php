<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Role;

class HomeController extends Controller
{
    
    public function index()
    {
    	if(\Auth::guest())
            return redirect()->route('login');

    
    	switch(\Auth::user()->role)
    	{
    		case Role::Admin:
    			return view('dashboard.admin');

    		case Role::HEI:
    			return view('dashboard.hei');

    		case Role::Supervisor:
    			return view('dashboard.supervisor');

            default:
                return 'No Assigned Role';
    	}
        
    }




    public function test()
    {
        $program = \App\Models\Application::where('schoolId',\Auth::user()->school->id)
                            ->where('status','draft') 
                            ->orderbyDesc('created_at')->get();

        // $program = \App\Models\SchoolCourse::select('course.id',
        //                                             'course.code as course_code',
        //                                             'course.description as course_desc',
        //                                             'school.id',
        //                                             'school.code as school_code',
        //                                             'school.type',
        //                                             'school.name',
        //                                             'school.province as province',
        //                                             'school.town',
        //                                             'school.recognition_number',
        //                                             'school.contact_person',
        //                                             'school.contact_number',

        //                                             'school.updated_by',
        //                                             'school.updated_at',
        //                                              'school-course.id')
        //                     ->join('school','school.id', '=','school-course.schoolId')
        //                     ->join('course', 'course.id', '=', 'school-course.courseId')
        //                     ->join('level', 'level.id','=', 'school-course.levelId')
        //                     ->where('school-course.id', 1)
        //                     ->get(); 
        
        dd($program);

        return \App\Models\Application::TrackingHashId(rand(1,1000));
    }
}
