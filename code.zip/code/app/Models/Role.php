<?php
/*
// Use const to prevent wrong comparison
// ex. kulang space, wrong capitalization
//
*/

namespace App\Models;

class Role
{	
	const Admin = 'admin';

	const HEI = 'hei';

	const Supervisor = 'supervisor';


	const AllRoles = ['admin', 'hei', 'supervisor'];
	
}